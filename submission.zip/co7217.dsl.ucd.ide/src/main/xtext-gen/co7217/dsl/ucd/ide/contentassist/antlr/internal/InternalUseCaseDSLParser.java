package co7217.dsl.ucd.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import co7217.dsl.ucd.services.UseCaseDSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalUseCaseDSLParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'use'", "'cases:'", "'useCase'", "'('", "')'", "'actors:'", "'actor'", "'=>'", "'extends'", "','"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=6;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__20=20;

    // delegates
    // delegators


        public InternalUseCaseDSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalUseCaseDSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalUseCaseDSLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalUseCaseDSL.g"; }


    	private UseCaseDSLGrammarAccess grammarAccess;

    	public void setGrammarAccess(UseCaseDSLGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleUsecaseEMFModel"
    // InternalUseCaseDSL.g:53:1: entryRuleUsecaseEMFModel : ruleUsecaseEMFModel EOF ;
    public final void entryRuleUsecaseEMFModel() throws RecognitionException {
        try {
            // InternalUseCaseDSL.g:54:1: ( ruleUsecaseEMFModel EOF )
            // InternalUseCaseDSL.g:55:1: ruleUsecaseEMFModel EOF
            {
             before(grammarAccess.getUsecaseEMFModelRule()); 
            pushFollow(FOLLOW_1);
            ruleUsecaseEMFModel();

            state._fsp--;

             after(grammarAccess.getUsecaseEMFModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUsecaseEMFModel"


    // $ANTLR start "ruleUsecaseEMFModel"
    // InternalUseCaseDSL.g:62:1: ruleUsecaseEMFModel : ( ( rule__UsecaseEMFModel__Group__0 ) ) ;
    public final void ruleUsecaseEMFModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:66:2: ( ( ( rule__UsecaseEMFModel__Group__0 ) ) )
            // InternalUseCaseDSL.g:67:2: ( ( rule__UsecaseEMFModel__Group__0 ) )
            {
            // InternalUseCaseDSL.g:67:2: ( ( rule__UsecaseEMFModel__Group__0 ) )
            // InternalUseCaseDSL.g:68:3: ( rule__UsecaseEMFModel__Group__0 )
            {
             before(grammarAccess.getUsecaseEMFModelAccess().getGroup()); 
            // InternalUseCaseDSL.g:69:3: ( rule__UsecaseEMFModel__Group__0 )
            // InternalUseCaseDSL.g:69:4: rule__UsecaseEMFModel__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__UsecaseEMFModel__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getUsecaseEMFModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUsecaseEMFModel"


    // $ANTLR start "entryRuleUsecases"
    // InternalUseCaseDSL.g:78:1: entryRuleUsecases : ruleUsecases EOF ;
    public final void entryRuleUsecases() throws RecognitionException {
        try {
            // InternalUseCaseDSL.g:79:1: ( ruleUsecases EOF )
            // InternalUseCaseDSL.g:80:1: ruleUsecases EOF
            {
             before(grammarAccess.getUsecasesRule()); 
            pushFollow(FOLLOW_1);
            ruleUsecases();

            state._fsp--;

             after(grammarAccess.getUsecasesRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUsecases"


    // $ANTLR start "ruleUsecases"
    // InternalUseCaseDSL.g:87:1: ruleUsecases : ( ( rule__Usecases__Group__0 ) ) ;
    public final void ruleUsecases() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:91:2: ( ( ( rule__Usecases__Group__0 ) ) )
            // InternalUseCaseDSL.g:92:2: ( ( rule__Usecases__Group__0 ) )
            {
            // InternalUseCaseDSL.g:92:2: ( ( rule__Usecases__Group__0 ) )
            // InternalUseCaseDSL.g:93:3: ( rule__Usecases__Group__0 )
            {
             before(grammarAccess.getUsecasesAccess().getGroup()); 
            // InternalUseCaseDSL.g:94:3: ( rule__Usecases__Group__0 )
            // InternalUseCaseDSL.g:94:4: rule__Usecases__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Usecases__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getUsecasesAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUsecases"


    // $ANTLR start "entryRuleUseCase"
    // InternalUseCaseDSL.g:103:1: entryRuleUseCase : ruleUseCase EOF ;
    public final void entryRuleUseCase() throws RecognitionException {
        try {
            // InternalUseCaseDSL.g:104:1: ( ruleUseCase EOF )
            // InternalUseCaseDSL.g:105:1: ruleUseCase EOF
            {
             before(grammarAccess.getUseCaseRule()); 
            pushFollow(FOLLOW_1);
            ruleUseCase();

            state._fsp--;

             after(grammarAccess.getUseCaseRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUseCase"


    // $ANTLR start "ruleUseCase"
    // InternalUseCaseDSL.g:112:1: ruleUseCase : ( ( rule__UseCase__Group__0 ) ) ;
    public final void ruleUseCase() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:116:2: ( ( ( rule__UseCase__Group__0 ) ) )
            // InternalUseCaseDSL.g:117:2: ( ( rule__UseCase__Group__0 ) )
            {
            // InternalUseCaseDSL.g:117:2: ( ( rule__UseCase__Group__0 ) )
            // InternalUseCaseDSL.g:118:3: ( rule__UseCase__Group__0 )
            {
             before(grammarAccess.getUseCaseAccess().getGroup()); 
            // InternalUseCaseDSL.g:119:3: ( rule__UseCase__Group__0 )
            // InternalUseCaseDSL.g:119:4: rule__UseCase__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__UseCase__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getUseCaseAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUseCase"


    // $ANTLR start "entryRuleActors"
    // InternalUseCaseDSL.g:128:1: entryRuleActors : ruleActors EOF ;
    public final void entryRuleActors() throws RecognitionException {
        try {
            // InternalUseCaseDSL.g:129:1: ( ruleActors EOF )
            // InternalUseCaseDSL.g:130:1: ruleActors EOF
            {
             before(grammarAccess.getActorsRule()); 
            pushFollow(FOLLOW_1);
            ruleActors();

            state._fsp--;

             after(grammarAccess.getActorsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleActors"


    // $ANTLR start "ruleActors"
    // InternalUseCaseDSL.g:137:1: ruleActors : ( ( rule__Actors__Group__0 ) ) ;
    public final void ruleActors() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:141:2: ( ( ( rule__Actors__Group__0 ) ) )
            // InternalUseCaseDSL.g:142:2: ( ( rule__Actors__Group__0 ) )
            {
            // InternalUseCaseDSL.g:142:2: ( ( rule__Actors__Group__0 ) )
            // InternalUseCaseDSL.g:143:3: ( rule__Actors__Group__0 )
            {
             before(grammarAccess.getActorsAccess().getGroup()); 
            // InternalUseCaseDSL.g:144:3: ( rule__Actors__Group__0 )
            // InternalUseCaseDSL.g:144:4: rule__Actors__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Actors__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getActorsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleActors"


    // $ANTLR start "entryRuleActor"
    // InternalUseCaseDSL.g:153:1: entryRuleActor : ruleActor EOF ;
    public final void entryRuleActor() throws RecognitionException {
        try {
            // InternalUseCaseDSL.g:154:1: ( ruleActor EOF )
            // InternalUseCaseDSL.g:155:1: ruleActor EOF
            {
             before(grammarAccess.getActorRule()); 
            pushFollow(FOLLOW_1);
            ruleActor();

            state._fsp--;

             after(grammarAccess.getActorRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleActor"


    // $ANTLR start "ruleActor"
    // InternalUseCaseDSL.g:162:1: ruleActor : ( ( rule__Actor__Group__0 ) ) ;
    public final void ruleActor() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:166:2: ( ( ( rule__Actor__Group__0 ) ) )
            // InternalUseCaseDSL.g:167:2: ( ( rule__Actor__Group__0 ) )
            {
            // InternalUseCaseDSL.g:167:2: ( ( rule__Actor__Group__0 ) )
            // InternalUseCaseDSL.g:168:3: ( rule__Actor__Group__0 )
            {
             before(grammarAccess.getActorAccess().getGroup()); 
            // InternalUseCaseDSL.g:169:3: ( rule__Actor__Group__0 )
            // InternalUseCaseDSL.g:169:4: rule__Actor__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Actor__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getActorAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleActor"


    // $ANTLR start "rule__UsecaseEMFModel__Group__0"
    // InternalUseCaseDSL.g:177:1: rule__UsecaseEMFModel__Group__0 : rule__UsecaseEMFModel__Group__0__Impl rule__UsecaseEMFModel__Group__1 ;
    public final void rule__UsecaseEMFModel__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:181:1: ( rule__UsecaseEMFModel__Group__0__Impl rule__UsecaseEMFModel__Group__1 )
            // InternalUseCaseDSL.g:182:2: rule__UsecaseEMFModel__Group__0__Impl rule__UsecaseEMFModel__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__UsecaseEMFModel__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__UsecaseEMFModel__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UsecaseEMFModel__Group__0"


    // $ANTLR start "rule__UsecaseEMFModel__Group__0__Impl"
    // InternalUseCaseDSL.g:189:1: rule__UsecaseEMFModel__Group__0__Impl : ( ( rule__UsecaseEMFModel__UsecasesAssignment_0 )* ) ;
    public final void rule__UsecaseEMFModel__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:193:1: ( ( ( rule__UsecaseEMFModel__UsecasesAssignment_0 )* ) )
            // InternalUseCaseDSL.g:194:1: ( ( rule__UsecaseEMFModel__UsecasesAssignment_0 )* )
            {
            // InternalUseCaseDSL.g:194:1: ( ( rule__UsecaseEMFModel__UsecasesAssignment_0 )* )
            // InternalUseCaseDSL.g:195:2: ( rule__UsecaseEMFModel__UsecasesAssignment_0 )*
            {
             before(grammarAccess.getUsecaseEMFModelAccess().getUsecasesAssignment_0()); 
            // InternalUseCaseDSL.g:196:2: ( rule__UsecaseEMFModel__UsecasesAssignment_0 )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalUseCaseDSL.g:196:3: rule__UsecaseEMFModel__UsecasesAssignment_0
            	    {
            	    pushFollow(FOLLOW_4);
            	    rule__UsecaseEMFModel__UsecasesAssignment_0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             after(grammarAccess.getUsecaseEMFModelAccess().getUsecasesAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UsecaseEMFModel__Group__0__Impl"


    // $ANTLR start "rule__UsecaseEMFModel__Group__1"
    // InternalUseCaseDSL.g:204:1: rule__UsecaseEMFModel__Group__1 : rule__UsecaseEMFModel__Group__1__Impl ;
    public final void rule__UsecaseEMFModel__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:208:1: ( rule__UsecaseEMFModel__Group__1__Impl )
            // InternalUseCaseDSL.g:209:2: rule__UsecaseEMFModel__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__UsecaseEMFModel__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UsecaseEMFModel__Group__1"


    // $ANTLR start "rule__UsecaseEMFModel__Group__1__Impl"
    // InternalUseCaseDSL.g:215:1: rule__UsecaseEMFModel__Group__1__Impl : ( ( rule__UsecaseEMFModel__ActorAssignment_1 )* ) ;
    public final void rule__UsecaseEMFModel__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:219:1: ( ( ( rule__UsecaseEMFModel__ActorAssignment_1 )* ) )
            // InternalUseCaseDSL.g:220:1: ( ( rule__UsecaseEMFModel__ActorAssignment_1 )* )
            {
            // InternalUseCaseDSL.g:220:1: ( ( rule__UsecaseEMFModel__ActorAssignment_1 )* )
            // InternalUseCaseDSL.g:221:2: ( rule__UsecaseEMFModel__ActorAssignment_1 )*
            {
             before(grammarAccess.getUsecaseEMFModelAccess().getActorAssignment_1()); 
            // InternalUseCaseDSL.g:222:2: ( rule__UsecaseEMFModel__ActorAssignment_1 )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==16) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalUseCaseDSL.g:222:3: rule__UsecaseEMFModel__ActorAssignment_1
            	    {
            	    pushFollow(FOLLOW_5);
            	    rule__UsecaseEMFModel__ActorAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

             after(grammarAccess.getUsecaseEMFModelAccess().getActorAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UsecaseEMFModel__Group__1__Impl"


    // $ANTLR start "rule__Usecases__Group__0"
    // InternalUseCaseDSL.g:231:1: rule__Usecases__Group__0 : rule__Usecases__Group__0__Impl rule__Usecases__Group__1 ;
    public final void rule__Usecases__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:235:1: ( rule__Usecases__Group__0__Impl rule__Usecases__Group__1 )
            // InternalUseCaseDSL.g:236:2: rule__Usecases__Group__0__Impl rule__Usecases__Group__1
            {
            pushFollow(FOLLOW_6);
            rule__Usecases__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Usecases__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Usecases__Group__0"


    // $ANTLR start "rule__Usecases__Group__0__Impl"
    // InternalUseCaseDSL.g:243:1: rule__Usecases__Group__0__Impl : ( 'use' ) ;
    public final void rule__Usecases__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:247:1: ( ( 'use' ) )
            // InternalUseCaseDSL.g:248:1: ( 'use' )
            {
            // InternalUseCaseDSL.g:248:1: ( 'use' )
            // InternalUseCaseDSL.g:249:2: 'use'
            {
             before(grammarAccess.getUsecasesAccess().getUseKeyword_0()); 
            match(input,11,FOLLOW_2); 
             after(grammarAccess.getUsecasesAccess().getUseKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Usecases__Group__0__Impl"


    // $ANTLR start "rule__Usecases__Group__1"
    // InternalUseCaseDSL.g:258:1: rule__Usecases__Group__1 : rule__Usecases__Group__1__Impl rule__Usecases__Group__2 ;
    public final void rule__Usecases__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:262:1: ( rule__Usecases__Group__1__Impl rule__Usecases__Group__2 )
            // InternalUseCaseDSL.g:263:2: rule__Usecases__Group__1__Impl rule__Usecases__Group__2
            {
            pushFollow(FOLLOW_7);
            rule__Usecases__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Usecases__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Usecases__Group__1"


    // $ANTLR start "rule__Usecases__Group__1__Impl"
    // InternalUseCaseDSL.g:270:1: rule__Usecases__Group__1__Impl : ( 'cases:' ) ;
    public final void rule__Usecases__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:274:1: ( ( 'cases:' ) )
            // InternalUseCaseDSL.g:275:1: ( 'cases:' )
            {
            // InternalUseCaseDSL.g:275:1: ( 'cases:' )
            // InternalUseCaseDSL.g:276:2: 'cases:'
            {
             before(grammarAccess.getUsecasesAccess().getCasesKeyword_1()); 
            match(input,12,FOLLOW_2); 
             after(grammarAccess.getUsecasesAccess().getCasesKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Usecases__Group__1__Impl"


    // $ANTLR start "rule__Usecases__Group__2"
    // InternalUseCaseDSL.g:285:1: rule__Usecases__Group__2 : rule__Usecases__Group__2__Impl ;
    public final void rule__Usecases__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:289:1: ( rule__Usecases__Group__2__Impl )
            // InternalUseCaseDSL.g:290:2: rule__Usecases__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Usecases__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Usecases__Group__2"


    // $ANTLR start "rule__Usecases__Group__2__Impl"
    // InternalUseCaseDSL.g:296:1: rule__Usecases__Group__2__Impl : ( ( rule__Usecases__UseCaseAssignment_2 )* ) ;
    public final void rule__Usecases__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:300:1: ( ( ( rule__Usecases__UseCaseAssignment_2 )* ) )
            // InternalUseCaseDSL.g:301:1: ( ( rule__Usecases__UseCaseAssignment_2 )* )
            {
            // InternalUseCaseDSL.g:301:1: ( ( rule__Usecases__UseCaseAssignment_2 )* )
            // InternalUseCaseDSL.g:302:2: ( rule__Usecases__UseCaseAssignment_2 )*
            {
             before(grammarAccess.getUsecasesAccess().getUseCaseAssignment_2()); 
            // InternalUseCaseDSL.g:303:2: ( rule__Usecases__UseCaseAssignment_2 )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==13) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalUseCaseDSL.g:303:3: rule__Usecases__UseCaseAssignment_2
            	    {
            	    pushFollow(FOLLOW_8);
            	    rule__Usecases__UseCaseAssignment_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

             after(grammarAccess.getUsecasesAccess().getUseCaseAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Usecases__Group__2__Impl"


    // $ANTLR start "rule__UseCase__Group__0"
    // InternalUseCaseDSL.g:312:1: rule__UseCase__Group__0 : rule__UseCase__Group__0__Impl rule__UseCase__Group__1 ;
    public final void rule__UseCase__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:316:1: ( rule__UseCase__Group__0__Impl rule__UseCase__Group__1 )
            // InternalUseCaseDSL.g:317:2: rule__UseCase__Group__0__Impl rule__UseCase__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__UseCase__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__UseCase__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UseCase__Group__0"


    // $ANTLR start "rule__UseCase__Group__0__Impl"
    // InternalUseCaseDSL.g:324:1: rule__UseCase__Group__0__Impl : ( 'useCase' ) ;
    public final void rule__UseCase__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:328:1: ( ( 'useCase' ) )
            // InternalUseCaseDSL.g:329:1: ( 'useCase' )
            {
            // InternalUseCaseDSL.g:329:1: ( 'useCase' )
            // InternalUseCaseDSL.g:330:2: 'useCase'
            {
             before(grammarAccess.getUseCaseAccess().getUseCaseKeyword_0()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getUseCaseAccess().getUseCaseKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UseCase__Group__0__Impl"


    // $ANTLR start "rule__UseCase__Group__1"
    // InternalUseCaseDSL.g:339:1: rule__UseCase__Group__1 : rule__UseCase__Group__1__Impl rule__UseCase__Group__2 ;
    public final void rule__UseCase__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:343:1: ( rule__UseCase__Group__1__Impl rule__UseCase__Group__2 )
            // InternalUseCaseDSL.g:344:2: rule__UseCase__Group__1__Impl rule__UseCase__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__UseCase__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__UseCase__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UseCase__Group__1"


    // $ANTLR start "rule__UseCase__Group__1__Impl"
    // InternalUseCaseDSL.g:351:1: rule__UseCase__Group__1__Impl : ( ( rule__UseCase__NameAssignment_1 ) ) ;
    public final void rule__UseCase__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:355:1: ( ( ( rule__UseCase__NameAssignment_1 ) ) )
            // InternalUseCaseDSL.g:356:1: ( ( rule__UseCase__NameAssignment_1 ) )
            {
            // InternalUseCaseDSL.g:356:1: ( ( rule__UseCase__NameAssignment_1 ) )
            // InternalUseCaseDSL.g:357:2: ( rule__UseCase__NameAssignment_1 )
            {
             before(grammarAccess.getUseCaseAccess().getNameAssignment_1()); 
            // InternalUseCaseDSL.g:358:2: ( rule__UseCase__NameAssignment_1 )
            // InternalUseCaseDSL.g:358:3: rule__UseCase__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__UseCase__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getUseCaseAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UseCase__Group__1__Impl"


    // $ANTLR start "rule__UseCase__Group__2"
    // InternalUseCaseDSL.g:366:1: rule__UseCase__Group__2 : rule__UseCase__Group__2__Impl rule__UseCase__Group__3 ;
    public final void rule__UseCase__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:370:1: ( rule__UseCase__Group__2__Impl rule__UseCase__Group__3 )
            // InternalUseCaseDSL.g:371:2: rule__UseCase__Group__2__Impl rule__UseCase__Group__3
            {
            pushFollow(FOLLOW_11);
            rule__UseCase__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__UseCase__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UseCase__Group__2"


    // $ANTLR start "rule__UseCase__Group__2__Impl"
    // InternalUseCaseDSL.g:378:1: rule__UseCase__Group__2__Impl : ( '(' ) ;
    public final void rule__UseCase__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:382:1: ( ( '(' ) )
            // InternalUseCaseDSL.g:383:1: ( '(' )
            {
            // InternalUseCaseDSL.g:383:1: ( '(' )
            // InternalUseCaseDSL.g:384:2: '('
            {
             before(grammarAccess.getUseCaseAccess().getLeftParenthesisKeyword_2()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getUseCaseAccess().getLeftParenthesisKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UseCase__Group__2__Impl"


    // $ANTLR start "rule__UseCase__Group__3"
    // InternalUseCaseDSL.g:393:1: rule__UseCase__Group__3 : rule__UseCase__Group__3__Impl rule__UseCase__Group__4 ;
    public final void rule__UseCase__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:397:1: ( rule__UseCase__Group__3__Impl rule__UseCase__Group__4 )
            // InternalUseCaseDSL.g:398:2: rule__UseCase__Group__3__Impl rule__UseCase__Group__4
            {
            pushFollow(FOLLOW_12);
            rule__UseCase__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__UseCase__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UseCase__Group__3"


    // $ANTLR start "rule__UseCase__Group__3__Impl"
    // InternalUseCaseDSL.g:405:1: rule__UseCase__Group__3__Impl : ( ( rule__UseCase__TextAssignment_3 ) ) ;
    public final void rule__UseCase__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:409:1: ( ( ( rule__UseCase__TextAssignment_3 ) ) )
            // InternalUseCaseDSL.g:410:1: ( ( rule__UseCase__TextAssignment_3 ) )
            {
            // InternalUseCaseDSL.g:410:1: ( ( rule__UseCase__TextAssignment_3 ) )
            // InternalUseCaseDSL.g:411:2: ( rule__UseCase__TextAssignment_3 )
            {
             before(grammarAccess.getUseCaseAccess().getTextAssignment_3()); 
            // InternalUseCaseDSL.g:412:2: ( rule__UseCase__TextAssignment_3 )
            // InternalUseCaseDSL.g:412:3: rule__UseCase__TextAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__UseCase__TextAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getUseCaseAccess().getTextAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UseCase__Group__3__Impl"


    // $ANTLR start "rule__UseCase__Group__4"
    // InternalUseCaseDSL.g:420:1: rule__UseCase__Group__4 : rule__UseCase__Group__4__Impl ;
    public final void rule__UseCase__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:424:1: ( rule__UseCase__Group__4__Impl )
            // InternalUseCaseDSL.g:425:2: rule__UseCase__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__UseCase__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UseCase__Group__4"


    // $ANTLR start "rule__UseCase__Group__4__Impl"
    // InternalUseCaseDSL.g:431:1: rule__UseCase__Group__4__Impl : ( ')' ) ;
    public final void rule__UseCase__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:435:1: ( ( ')' ) )
            // InternalUseCaseDSL.g:436:1: ( ')' )
            {
            // InternalUseCaseDSL.g:436:1: ( ')' )
            // InternalUseCaseDSL.g:437:2: ')'
            {
             before(grammarAccess.getUseCaseAccess().getRightParenthesisKeyword_4()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getUseCaseAccess().getRightParenthesisKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UseCase__Group__4__Impl"


    // $ANTLR start "rule__Actors__Group__0"
    // InternalUseCaseDSL.g:447:1: rule__Actors__Group__0 : rule__Actors__Group__0__Impl rule__Actors__Group__1 ;
    public final void rule__Actors__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:451:1: ( rule__Actors__Group__0__Impl rule__Actors__Group__1 )
            // InternalUseCaseDSL.g:452:2: rule__Actors__Group__0__Impl rule__Actors__Group__1
            {
            pushFollow(FOLLOW_13);
            rule__Actors__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Actors__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actors__Group__0"


    // $ANTLR start "rule__Actors__Group__0__Impl"
    // InternalUseCaseDSL.g:459:1: rule__Actors__Group__0__Impl : ( 'actors:' ) ;
    public final void rule__Actors__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:463:1: ( ( 'actors:' ) )
            // InternalUseCaseDSL.g:464:1: ( 'actors:' )
            {
            // InternalUseCaseDSL.g:464:1: ( 'actors:' )
            // InternalUseCaseDSL.g:465:2: 'actors:'
            {
             before(grammarAccess.getActorsAccess().getActorsKeyword_0()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getActorsAccess().getActorsKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actors__Group__0__Impl"


    // $ANTLR start "rule__Actors__Group__1"
    // InternalUseCaseDSL.g:474:1: rule__Actors__Group__1 : rule__Actors__Group__1__Impl ;
    public final void rule__Actors__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:478:1: ( rule__Actors__Group__1__Impl )
            // InternalUseCaseDSL.g:479:2: rule__Actors__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Actors__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actors__Group__1"


    // $ANTLR start "rule__Actors__Group__1__Impl"
    // InternalUseCaseDSL.g:485:1: rule__Actors__Group__1__Impl : ( ( rule__Actors__ActorAssignment_1 )* ) ;
    public final void rule__Actors__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:489:1: ( ( ( rule__Actors__ActorAssignment_1 )* ) )
            // InternalUseCaseDSL.g:490:1: ( ( rule__Actors__ActorAssignment_1 )* )
            {
            // InternalUseCaseDSL.g:490:1: ( ( rule__Actors__ActorAssignment_1 )* )
            // InternalUseCaseDSL.g:491:2: ( rule__Actors__ActorAssignment_1 )*
            {
             before(grammarAccess.getActorsAccess().getActorAssignment_1()); 
            // InternalUseCaseDSL.g:492:2: ( rule__Actors__ActorAssignment_1 )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==17) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalUseCaseDSL.g:492:3: rule__Actors__ActorAssignment_1
            	    {
            	    pushFollow(FOLLOW_14);
            	    rule__Actors__ActorAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

             after(grammarAccess.getActorsAccess().getActorAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actors__Group__1__Impl"


    // $ANTLR start "rule__Actor__Group__0"
    // InternalUseCaseDSL.g:501:1: rule__Actor__Group__0 : rule__Actor__Group__0__Impl rule__Actor__Group__1 ;
    public final void rule__Actor__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:505:1: ( rule__Actor__Group__0__Impl rule__Actor__Group__1 )
            // InternalUseCaseDSL.g:506:2: rule__Actor__Group__0__Impl rule__Actor__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__Actor__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Actor__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group__0"


    // $ANTLR start "rule__Actor__Group__0__Impl"
    // InternalUseCaseDSL.g:513:1: rule__Actor__Group__0__Impl : ( 'actor' ) ;
    public final void rule__Actor__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:517:1: ( ( 'actor' ) )
            // InternalUseCaseDSL.g:518:1: ( 'actor' )
            {
            // InternalUseCaseDSL.g:518:1: ( 'actor' )
            // InternalUseCaseDSL.g:519:2: 'actor'
            {
             before(grammarAccess.getActorAccess().getActorKeyword_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getActorAccess().getActorKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group__0__Impl"


    // $ANTLR start "rule__Actor__Group__1"
    // InternalUseCaseDSL.g:528:1: rule__Actor__Group__1 : rule__Actor__Group__1__Impl rule__Actor__Group__2 ;
    public final void rule__Actor__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:532:1: ( rule__Actor__Group__1__Impl rule__Actor__Group__2 )
            // InternalUseCaseDSL.g:533:2: rule__Actor__Group__1__Impl rule__Actor__Group__2
            {
            pushFollow(FOLLOW_15);
            rule__Actor__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Actor__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group__1"


    // $ANTLR start "rule__Actor__Group__1__Impl"
    // InternalUseCaseDSL.g:540:1: rule__Actor__Group__1__Impl : ( ( rule__Actor__NameAssignment_1 ) ) ;
    public final void rule__Actor__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:544:1: ( ( ( rule__Actor__NameAssignment_1 ) ) )
            // InternalUseCaseDSL.g:545:1: ( ( rule__Actor__NameAssignment_1 ) )
            {
            // InternalUseCaseDSL.g:545:1: ( ( rule__Actor__NameAssignment_1 ) )
            // InternalUseCaseDSL.g:546:2: ( rule__Actor__NameAssignment_1 )
            {
             before(grammarAccess.getActorAccess().getNameAssignment_1()); 
            // InternalUseCaseDSL.g:547:2: ( rule__Actor__NameAssignment_1 )
            // InternalUseCaseDSL.g:547:3: rule__Actor__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Actor__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getActorAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group__1__Impl"


    // $ANTLR start "rule__Actor__Group__2"
    // InternalUseCaseDSL.g:555:1: rule__Actor__Group__2 : rule__Actor__Group__2__Impl rule__Actor__Group__3 ;
    public final void rule__Actor__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:559:1: ( rule__Actor__Group__2__Impl rule__Actor__Group__3 )
            // InternalUseCaseDSL.g:560:2: rule__Actor__Group__2__Impl rule__Actor__Group__3
            {
            pushFollow(FOLLOW_15);
            rule__Actor__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Actor__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group__2"


    // $ANTLR start "rule__Actor__Group__2__Impl"
    // InternalUseCaseDSL.g:567:1: rule__Actor__Group__2__Impl : ( ( rule__Actor__Group_2__0 )? ) ;
    public final void rule__Actor__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:571:1: ( ( ( rule__Actor__Group_2__0 )? ) )
            // InternalUseCaseDSL.g:572:1: ( ( rule__Actor__Group_2__0 )? )
            {
            // InternalUseCaseDSL.g:572:1: ( ( rule__Actor__Group_2__0 )? )
            // InternalUseCaseDSL.g:573:2: ( rule__Actor__Group_2__0 )?
            {
             before(grammarAccess.getActorAccess().getGroup_2()); 
            // InternalUseCaseDSL.g:574:2: ( rule__Actor__Group_2__0 )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==19) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalUseCaseDSL.g:574:3: rule__Actor__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Actor__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getActorAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group__2__Impl"


    // $ANTLR start "rule__Actor__Group__3"
    // InternalUseCaseDSL.g:582:1: rule__Actor__Group__3 : rule__Actor__Group__3__Impl rule__Actor__Group__4 ;
    public final void rule__Actor__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:586:1: ( rule__Actor__Group__3__Impl rule__Actor__Group__4 )
            // InternalUseCaseDSL.g:587:2: rule__Actor__Group__3__Impl rule__Actor__Group__4
            {
            pushFollow(FOLLOW_16);
            rule__Actor__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Actor__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group__3"


    // $ANTLR start "rule__Actor__Group__3__Impl"
    // InternalUseCaseDSL.g:594:1: rule__Actor__Group__3__Impl : ( '=>' ) ;
    public final void rule__Actor__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:598:1: ( ( '=>' ) )
            // InternalUseCaseDSL.g:599:1: ( '=>' )
            {
            // InternalUseCaseDSL.g:599:1: ( '=>' )
            // InternalUseCaseDSL.g:600:2: '=>'
            {
             before(grammarAccess.getActorAccess().getEqualsSignGreaterThanSignKeyword_3()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getActorAccess().getEqualsSignGreaterThanSignKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group__3__Impl"


    // $ANTLR start "rule__Actor__Group__4"
    // InternalUseCaseDSL.g:609:1: rule__Actor__Group__4 : rule__Actor__Group__4__Impl rule__Actor__Group__5 ;
    public final void rule__Actor__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:613:1: ( rule__Actor__Group__4__Impl rule__Actor__Group__5 )
            // InternalUseCaseDSL.g:614:2: rule__Actor__Group__4__Impl rule__Actor__Group__5
            {
            pushFollow(FOLLOW_16);
            rule__Actor__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Actor__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group__4"


    // $ANTLR start "rule__Actor__Group__4__Impl"
    // InternalUseCaseDSL.g:621:1: rule__Actor__Group__4__Impl : ( ( rule__Actor__UsecaseAssignment_4 )* ) ;
    public final void rule__Actor__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:625:1: ( ( ( rule__Actor__UsecaseAssignment_4 )* ) )
            // InternalUseCaseDSL.g:626:1: ( ( rule__Actor__UsecaseAssignment_4 )* )
            {
            // InternalUseCaseDSL.g:626:1: ( ( rule__Actor__UsecaseAssignment_4 )* )
            // InternalUseCaseDSL.g:627:2: ( rule__Actor__UsecaseAssignment_4 )*
            {
             before(grammarAccess.getActorAccess().getUsecaseAssignment_4()); 
            // InternalUseCaseDSL.g:628:2: ( rule__Actor__UsecaseAssignment_4 )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==RULE_ID) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalUseCaseDSL.g:628:3: rule__Actor__UsecaseAssignment_4
            	    {
            	    pushFollow(FOLLOW_17);
            	    rule__Actor__UsecaseAssignment_4();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

             after(grammarAccess.getActorAccess().getUsecaseAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group__4__Impl"


    // $ANTLR start "rule__Actor__Group__5"
    // InternalUseCaseDSL.g:636:1: rule__Actor__Group__5 : rule__Actor__Group__5__Impl ;
    public final void rule__Actor__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:640:1: ( rule__Actor__Group__5__Impl )
            // InternalUseCaseDSL.g:641:2: rule__Actor__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Actor__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group__5"


    // $ANTLR start "rule__Actor__Group__5__Impl"
    // InternalUseCaseDSL.g:647:1: rule__Actor__Group__5__Impl : ( ( rule__Actor__Group_5__0 )* ) ;
    public final void rule__Actor__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:651:1: ( ( ( rule__Actor__Group_5__0 )* ) )
            // InternalUseCaseDSL.g:652:1: ( ( rule__Actor__Group_5__0 )* )
            {
            // InternalUseCaseDSL.g:652:1: ( ( rule__Actor__Group_5__0 )* )
            // InternalUseCaseDSL.g:653:2: ( rule__Actor__Group_5__0 )*
            {
             before(grammarAccess.getActorAccess().getGroup_5()); 
            // InternalUseCaseDSL.g:654:2: ( rule__Actor__Group_5__0 )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==20) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalUseCaseDSL.g:654:3: rule__Actor__Group_5__0
            	    {
            	    pushFollow(FOLLOW_18);
            	    rule__Actor__Group_5__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

             after(grammarAccess.getActorAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group__5__Impl"


    // $ANTLR start "rule__Actor__Group_2__0"
    // InternalUseCaseDSL.g:663:1: rule__Actor__Group_2__0 : rule__Actor__Group_2__0__Impl rule__Actor__Group_2__1 ;
    public final void rule__Actor__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:667:1: ( rule__Actor__Group_2__0__Impl rule__Actor__Group_2__1 )
            // InternalUseCaseDSL.g:668:2: rule__Actor__Group_2__0__Impl rule__Actor__Group_2__1
            {
            pushFollow(FOLLOW_9);
            rule__Actor__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Actor__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group_2__0"


    // $ANTLR start "rule__Actor__Group_2__0__Impl"
    // InternalUseCaseDSL.g:675:1: rule__Actor__Group_2__0__Impl : ( 'extends' ) ;
    public final void rule__Actor__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:679:1: ( ( 'extends' ) )
            // InternalUseCaseDSL.g:680:1: ( 'extends' )
            {
            // InternalUseCaseDSL.g:680:1: ( 'extends' )
            // InternalUseCaseDSL.g:681:2: 'extends'
            {
             before(grammarAccess.getActorAccess().getExtendsKeyword_2_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getActorAccess().getExtendsKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group_2__0__Impl"


    // $ANTLR start "rule__Actor__Group_2__1"
    // InternalUseCaseDSL.g:690:1: rule__Actor__Group_2__1 : rule__Actor__Group_2__1__Impl ;
    public final void rule__Actor__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:694:1: ( rule__Actor__Group_2__1__Impl )
            // InternalUseCaseDSL.g:695:2: rule__Actor__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Actor__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group_2__1"


    // $ANTLR start "rule__Actor__Group_2__1__Impl"
    // InternalUseCaseDSL.g:701:1: rule__Actor__Group_2__1__Impl : ( ( rule__Actor__SuperTypeAssignment_2_1 ) ) ;
    public final void rule__Actor__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:705:1: ( ( ( rule__Actor__SuperTypeAssignment_2_1 ) ) )
            // InternalUseCaseDSL.g:706:1: ( ( rule__Actor__SuperTypeAssignment_2_1 ) )
            {
            // InternalUseCaseDSL.g:706:1: ( ( rule__Actor__SuperTypeAssignment_2_1 ) )
            // InternalUseCaseDSL.g:707:2: ( rule__Actor__SuperTypeAssignment_2_1 )
            {
             before(grammarAccess.getActorAccess().getSuperTypeAssignment_2_1()); 
            // InternalUseCaseDSL.g:708:2: ( rule__Actor__SuperTypeAssignment_2_1 )
            // InternalUseCaseDSL.g:708:3: rule__Actor__SuperTypeAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Actor__SuperTypeAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getActorAccess().getSuperTypeAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group_2__1__Impl"


    // $ANTLR start "rule__Actor__Group_5__0"
    // InternalUseCaseDSL.g:717:1: rule__Actor__Group_5__0 : rule__Actor__Group_5__0__Impl rule__Actor__Group_5__1 ;
    public final void rule__Actor__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:721:1: ( rule__Actor__Group_5__0__Impl rule__Actor__Group_5__1 )
            // InternalUseCaseDSL.g:722:2: rule__Actor__Group_5__0__Impl rule__Actor__Group_5__1
            {
            pushFollow(FOLLOW_9);
            rule__Actor__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Actor__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group_5__0"


    // $ANTLR start "rule__Actor__Group_5__0__Impl"
    // InternalUseCaseDSL.g:729:1: rule__Actor__Group_5__0__Impl : ( ',' ) ;
    public final void rule__Actor__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:733:1: ( ( ',' ) )
            // InternalUseCaseDSL.g:734:1: ( ',' )
            {
            // InternalUseCaseDSL.g:734:1: ( ',' )
            // InternalUseCaseDSL.g:735:2: ','
            {
             before(grammarAccess.getActorAccess().getCommaKeyword_5_0()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getActorAccess().getCommaKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group_5__0__Impl"


    // $ANTLR start "rule__Actor__Group_5__1"
    // InternalUseCaseDSL.g:744:1: rule__Actor__Group_5__1 : rule__Actor__Group_5__1__Impl ;
    public final void rule__Actor__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:748:1: ( rule__Actor__Group_5__1__Impl )
            // InternalUseCaseDSL.g:749:2: rule__Actor__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Actor__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group_5__1"


    // $ANTLR start "rule__Actor__Group_5__1__Impl"
    // InternalUseCaseDSL.g:755:1: rule__Actor__Group_5__1__Impl : ( ( rule__Actor__UsecaseAssignment_5_1 ) ) ;
    public final void rule__Actor__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:759:1: ( ( ( rule__Actor__UsecaseAssignment_5_1 ) ) )
            // InternalUseCaseDSL.g:760:1: ( ( rule__Actor__UsecaseAssignment_5_1 ) )
            {
            // InternalUseCaseDSL.g:760:1: ( ( rule__Actor__UsecaseAssignment_5_1 ) )
            // InternalUseCaseDSL.g:761:2: ( rule__Actor__UsecaseAssignment_5_1 )
            {
             before(grammarAccess.getActorAccess().getUsecaseAssignment_5_1()); 
            // InternalUseCaseDSL.g:762:2: ( rule__Actor__UsecaseAssignment_5_1 )
            // InternalUseCaseDSL.g:762:3: rule__Actor__UsecaseAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__Actor__UsecaseAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getActorAccess().getUsecaseAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__Group_5__1__Impl"


    // $ANTLR start "rule__UsecaseEMFModel__UsecasesAssignment_0"
    // InternalUseCaseDSL.g:771:1: rule__UsecaseEMFModel__UsecasesAssignment_0 : ( ruleUsecases ) ;
    public final void rule__UsecaseEMFModel__UsecasesAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:775:1: ( ( ruleUsecases ) )
            // InternalUseCaseDSL.g:776:2: ( ruleUsecases )
            {
            // InternalUseCaseDSL.g:776:2: ( ruleUsecases )
            // InternalUseCaseDSL.g:777:3: ruleUsecases
            {
             before(grammarAccess.getUsecaseEMFModelAccess().getUsecasesUsecasesParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleUsecases();

            state._fsp--;

             after(grammarAccess.getUsecaseEMFModelAccess().getUsecasesUsecasesParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UsecaseEMFModel__UsecasesAssignment_0"


    // $ANTLR start "rule__UsecaseEMFModel__ActorAssignment_1"
    // InternalUseCaseDSL.g:786:1: rule__UsecaseEMFModel__ActorAssignment_1 : ( ruleActors ) ;
    public final void rule__UsecaseEMFModel__ActorAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:790:1: ( ( ruleActors ) )
            // InternalUseCaseDSL.g:791:2: ( ruleActors )
            {
            // InternalUseCaseDSL.g:791:2: ( ruleActors )
            // InternalUseCaseDSL.g:792:3: ruleActors
            {
             before(grammarAccess.getUsecaseEMFModelAccess().getActorActorsParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleActors();

            state._fsp--;

             after(grammarAccess.getUsecaseEMFModelAccess().getActorActorsParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UsecaseEMFModel__ActorAssignment_1"


    // $ANTLR start "rule__Usecases__UseCaseAssignment_2"
    // InternalUseCaseDSL.g:801:1: rule__Usecases__UseCaseAssignment_2 : ( ruleUseCase ) ;
    public final void rule__Usecases__UseCaseAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:805:1: ( ( ruleUseCase ) )
            // InternalUseCaseDSL.g:806:2: ( ruleUseCase )
            {
            // InternalUseCaseDSL.g:806:2: ( ruleUseCase )
            // InternalUseCaseDSL.g:807:3: ruleUseCase
            {
             before(grammarAccess.getUsecasesAccess().getUseCaseUseCaseParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleUseCase();

            state._fsp--;

             after(grammarAccess.getUsecasesAccess().getUseCaseUseCaseParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Usecases__UseCaseAssignment_2"


    // $ANTLR start "rule__UseCase__NameAssignment_1"
    // InternalUseCaseDSL.g:816:1: rule__UseCase__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__UseCase__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:820:1: ( ( RULE_ID ) )
            // InternalUseCaseDSL.g:821:2: ( RULE_ID )
            {
            // InternalUseCaseDSL.g:821:2: ( RULE_ID )
            // InternalUseCaseDSL.g:822:3: RULE_ID
            {
             before(grammarAccess.getUseCaseAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getUseCaseAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UseCase__NameAssignment_1"


    // $ANTLR start "rule__UseCase__TextAssignment_3"
    // InternalUseCaseDSL.g:831:1: rule__UseCase__TextAssignment_3 : ( RULE_STRING ) ;
    public final void rule__UseCase__TextAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:835:1: ( ( RULE_STRING ) )
            // InternalUseCaseDSL.g:836:2: ( RULE_STRING )
            {
            // InternalUseCaseDSL.g:836:2: ( RULE_STRING )
            // InternalUseCaseDSL.g:837:3: RULE_STRING
            {
             before(grammarAccess.getUseCaseAccess().getTextSTRINGTerminalRuleCall_3_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getUseCaseAccess().getTextSTRINGTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__UseCase__TextAssignment_3"


    // $ANTLR start "rule__Actors__ActorAssignment_1"
    // InternalUseCaseDSL.g:846:1: rule__Actors__ActorAssignment_1 : ( ruleActor ) ;
    public final void rule__Actors__ActorAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:850:1: ( ( ruleActor ) )
            // InternalUseCaseDSL.g:851:2: ( ruleActor )
            {
            // InternalUseCaseDSL.g:851:2: ( ruleActor )
            // InternalUseCaseDSL.g:852:3: ruleActor
            {
             before(grammarAccess.getActorsAccess().getActorActorParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleActor();

            state._fsp--;

             after(grammarAccess.getActorsAccess().getActorActorParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actors__ActorAssignment_1"


    // $ANTLR start "rule__Actor__NameAssignment_1"
    // InternalUseCaseDSL.g:861:1: rule__Actor__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Actor__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:865:1: ( ( RULE_ID ) )
            // InternalUseCaseDSL.g:866:2: ( RULE_ID )
            {
            // InternalUseCaseDSL.g:866:2: ( RULE_ID )
            // InternalUseCaseDSL.g:867:3: RULE_ID
            {
             before(grammarAccess.getActorAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getActorAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__NameAssignment_1"


    // $ANTLR start "rule__Actor__SuperTypeAssignment_2_1"
    // InternalUseCaseDSL.g:876:1: rule__Actor__SuperTypeAssignment_2_1 : ( ( RULE_ID ) ) ;
    public final void rule__Actor__SuperTypeAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:880:1: ( ( ( RULE_ID ) ) )
            // InternalUseCaseDSL.g:881:2: ( ( RULE_ID ) )
            {
            // InternalUseCaseDSL.g:881:2: ( ( RULE_ID ) )
            // InternalUseCaseDSL.g:882:3: ( RULE_ID )
            {
             before(grammarAccess.getActorAccess().getSuperTypeActorCrossReference_2_1_0()); 
            // InternalUseCaseDSL.g:883:3: ( RULE_ID )
            // InternalUseCaseDSL.g:884:4: RULE_ID
            {
             before(grammarAccess.getActorAccess().getSuperTypeActorIDTerminalRuleCall_2_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getActorAccess().getSuperTypeActorIDTerminalRuleCall_2_1_0_1()); 

            }

             after(grammarAccess.getActorAccess().getSuperTypeActorCrossReference_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__SuperTypeAssignment_2_1"


    // $ANTLR start "rule__Actor__UsecaseAssignment_4"
    // InternalUseCaseDSL.g:895:1: rule__Actor__UsecaseAssignment_4 : ( ( RULE_ID ) ) ;
    public final void rule__Actor__UsecaseAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:899:1: ( ( ( RULE_ID ) ) )
            // InternalUseCaseDSL.g:900:2: ( ( RULE_ID ) )
            {
            // InternalUseCaseDSL.g:900:2: ( ( RULE_ID ) )
            // InternalUseCaseDSL.g:901:3: ( RULE_ID )
            {
             before(grammarAccess.getActorAccess().getUsecaseUseCaseCrossReference_4_0()); 
            // InternalUseCaseDSL.g:902:3: ( RULE_ID )
            // InternalUseCaseDSL.g:903:4: RULE_ID
            {
             before(grammarAccess.getActorAccess().getUsecaseUseCaseIDTerminalRuleCall_4_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getActorAccess().getUsecaseUseCaseIDTerminalRuleCall_4_0_1()); 

            }

             after(grammarAccess.getActorAccess().getUsecaseUseCaseCrossReference_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__UsecaseAssignment_4"


    // $ANTLR start "rule__Actor__UsecaseAssignment_5_1"
    // InternalUseCaseDSL.g:914:1: rule__Actor__UsecaseAssignment_5_1 : ( ( RULE_ID ) ) ;
    public final void rule__Actor__UsecaseAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalUseCaseDSL.g:918:1: ( ( ( RULE_ID ) ) )
            // InternalUseCaseDSL.g:919:2: ( ( RULE_ID ) )
            {
            // InternalUseCaseDSL.g:919:2: ( ( RULE_ID ) )
            // InternalUseCaseDSL.g:920:3: ( RULE_ID )
            {
             before(grammarAccess.getActorAccess().getUsecaseUseCaseCrossReference_5_1_0()); 
            // InternalUseCaseDSL.g:921:3: ( RULE_ID )
            // InternalUseCaseDSL.g:922:4: RULE_ID
            {
             before(grammarAccess.getActorAccess().getUsecaseUseCaseIDTerminalRuleCall_5_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getActorAccess().getUsecaseUseCaseIDTerminalRuleCall_5_1_0_1()); 

            }

             after(grammarAccess.getActorAccess().getUsecaseUseCaseCrossReference_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Actor__UsecaseAssignment_5_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000002002L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000100010L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000100002L});

}