package co7217.dsl.ucd.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import co7217.dsl.ucd.services.UseCaseDSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalUseCaseDSLParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'use'", "'cases:'", "'useCase'", "'('", "')'", "'actors:'", "'actor'", "'extends'", "'=>'", "','"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=6;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__20=20;

    // delegates
    // delegators


        public InternalUseCaseDSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalUseCaseDSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalUseCaseDSLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalUseCaseDSL.g"; }



     	private UseCaseDSLGrammarAccess grammarAccess;

        public InternalUseCaseDSLParser(TokenStream input, UseCaseDSLGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "UsecaseEMFModel";
       	}

       	@Override
       	protected UseCaseDSLGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleUsecaseEMFModel"
    // InternalUseCaseDSL.g:64:1: entryRuleUsecaseEMFModel returns [EObject current=null] : iv_ruleUsecaseEMFModel= ruleUsecaseEMFModel EOF ;
    public final EObject entryRuleUsecaseEMFModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUsecaseEMFModel = null;


        try {
            // InternalUseCaseDSL.g:64:56: (iv_ruleUsecaseEMFModel= ruleUsecaseEMFModel EOF )
            // InternalUseCaseDSL.g:65:2: iv_ruleUsecaseEMFModel= ruleUsecaseEMFModel EOF
            {
             newCompositeNode(grammarAccess.getUsecaseEMFModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUsecaseEMFModel=ruleUsecaseEMFModel();

            state._fsp--;

             current =iv_ruleUsecaseEMFModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUsecaseEMFModel"


    // $ANTLR start "ruleUsecaseEMFModel"
    // InternalUseCaseDSL.g:71:1: ruleUsecaseEMFModel returns [EObject current=null] : ( ( (lv_usecases_0_0= ruleUsecases ) )* ( (lv_actor_1_0= ruleActors ) )* ) ;
    public final EObject ruleUsecaseEMFModel() throws RecognitionException {
        EObject current = null;

        EObject lv_usecases_0_0 = null;

        EObject lv_actor_1_0 = null;



        	enterRule();

        try {
            // InternalUseCaseDSL.g:77:2: ( ( ( (lv_usecases_0_0= ruleUsecases ) )* ( (lv_actor_1_0= ruleActors ) )* ) )
            // InternalUseCaseDSL.g:78:2: ( ( (lv_usecases_0_0= ruleUsecases ) )* ( (lv_actor_1_0= ruleActors ) )* )
            {
            // InternalUseCaseDSL.g:78:2: ( ( (lv_usecases_0_0= ruleUsecases ) )* ( (lv_actor_1_0= ruleActors ) )* )
            // InternalUseCaseDSL.g:79:3: ( (lv_usecases_0_0= ruleUsecases ) )* ( (lv_actor_1_0= ruleActors ) )*
            {
            // InternalUseCaseDSL.g:79:3: ( (lv_usecases_0_0= ruleUsecases ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalUseCaseDSL.g:80:4: (lv_usecases_0_0= ruleUsecases )
            	    {
            	    // InternalUseCaseDSL.g:80:4: (lv_usecases_0_0= ruleUsecases )
            	    // InternalUseCaseDSL.g:81:5: lv_usecases_0_0= ruleUsecases
            	    {

            	    					newCompositeNode(grammarAccess.getUsecaseEMFModelAccess().getUsecasesUsecasesParserRuleCall_0_0());
            	    				
            	    pushFollow(FOLLOW_3);
            	    lv_usecases_0_0=ruleUsecases();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getUsecaseEMFModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"usecases",
            	    						lv_usecases_0_0,
            	    						"co7217.dsl.ucd.UseCaseDSL.Usecases");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            // InternalUseCaseDSL.g:98:3: ( (lv_actor_1_0= ruleActors ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==16) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalUseCaseDSL.g:99:4: (lv_actor_1_0= ruleActors )
            	    {
            	    // InternalUseCaseDSL.g:99:4: (lv_actor_1_0= ruleActors )
            	    // InternalUseCaseDSL.g:100:5: lv_actor_1_0= ruleActors
            	    {

            	    					newCompositeNode(grammarAccess.getUsecaseEMFModelAccess().getActorActorsParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_actor_1_0=ruleActors();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getUsecaseEMFModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"actor",
            	    						lv_actor_1_0,
            	    						"co7217.dsl.ucd.UseCaseDSL.Actors");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUsecaseEMFModel"


    // $ANTLR start "entryRuleUsecases"
    // InternalUseCaseDSL.g:121:1: entryRuleUsecases returns [EObject current=null] : iv_ruleUsecases= ruleUsecases EOF ;
    public final EObject entryRuleUsecases() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUsecases = null;


        try {
            // InternalUseCaseDSL.g:121:49: (iv_ruleUsecases= ruleUsecases EOF )
            // InternalUseCaseDSL.g:122:2: iv_ruleUsecases= ruleUsecases EOF
            {
             newCompositeNode(grammarAccess.getUsecasesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUsecases=ruleUsecases();

            state._fsp--;

             current =iv_ruleUsecases; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUsecases"


    // $ANTLR start "ruleUsecases"
    // InternalUseCaseDSL.g:128:1: ruleUsecases returns [EObject current=null] : (otherlv_0= 'use' otherlv_1= 'cases:' ( (lv_useCase_2_0= ruleUseCase ) )* ) ;
    public final EObject ruleUsecases() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        EObject lv_useCase_2_0 = null;



        	enterRule();

        try {
            // InternalUseCaseDSL.g:134:2: ( (otherlv_0= 'use' otherlv_1= 'cases:' ( (lv_useCase_2_0= ruleUseCase ) )* ) )
            // InternalUseCaseDSL.g:135:2: (otherlv_0= 'use' otherlv_1= 'cases:' ( (lv_useCase_2_0= ruleUseCase ) )* )
            {
            // InternalUseCaseDSL.g:135:2: (otherlv_0= 'use' otherlv_1= 'cases:' ( (lv_useCase_2_0= ruleUseCase ) )* )
            // InternalUseCaseDSL.g:136:3: otherlv_0= 'use' otherlv_1= 'cases:' ( (lv_useCase_2_0= ruleUseCase ) )*
            {
            otherlv_0=(Token)match(input,11,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getUsecasesAccess().getUseKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_1, grammarAccess.getUsecasesAccess().getCasesKeyword_1());
            		
            // InternalUseCaseDSL.g:144:3: ( (lv_useCase_2_0= ruleUseCase ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==13) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalUseCaseDSL.g:145:4: (lv_useCase_2_0= ruleUseCase )
            	    {
            	    // InternalUseCaseDSL.g:145:4: (lv_useCase_2_0= ruleUseCase )
            	    // InternalUseCaseDSL.g:146:5: lv_useCase_2_0= ruleUseCase
            	    {

            	    					newCompositeNode(grammarAccess.getUsecasesAccess().getUseCaseUseCaseParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_6);
            	    lv_useCase_2_0=ruleUseCase();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getUsecasesRule());
            	    					}
            	    					add(
            	    						current,
            	    						"useCase",
            	    						lv_useCase_2_0,
            	    						"co7217.dsl.ucd.UseCaseDSL.UseCase");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUsecases"


    // $ANTLR start "entryRuleUseCase"
    // InternalUseCaseDSL.g:167:1: entryRuleUseCase returns [EObject current=null] : iv_ruleUseCase= ruleUseCase EOF ;
    public final EObject entryRuleUseCase() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUseCase = null;


        try {
            // InternalUseCaseDSL.g:167:48: (iv_ruleUseCase= ruleUseCase EOF )
            // InternalUseCaseDSL.g:168:2: iv_ruleUseCase= ruleUseCase EOF
            {
             newCompositeNode(grammarAccess.getUseCaseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUseCase=ruleUseCase();

            state._fsp--;

             current =iv_ruleUseCase; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUseCase"


    // $ANTLR start "ruleUseCase"
    // InternalUseCaseDSL.g:174:1: ruleUseCase returns [EObject current=null] : (otherlv_0= 'useCase' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_text_3_0= RULE_STRING ) ) otherlv_4= ')' ) ;
    public final EObject ruleUseCase() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_text_3_0=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalUseCaseDSL.g:180:2: ( (otherlv_0= 'useCase' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_text_3_0= RULE_STRING ) ) otherlv_4= ')' ) )
            // InternalUseCaseDSL.g:181:2: (otherlv_0= 'useCase' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_text_3_0= RULE_STRING ) ) otherlv_4= ')' )
            {
            // InternalUseCaseDSL.g:181:2: (otherlv_0= 'useCase' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_text_3_0= RULE_STRING ) ) otherlv_4= ')' )
            // InternalUseCaseDSL.g:182:3: otherlv_0= 'useCase' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_text_3_0= RULE_STRING ) ) otherlv_4= ')'
            {
            otherlv_0=(Token)match(input,13,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getUseCaseAccess().getUseCaseKeyword_0());
            		
            // InternalUseCaseDSL.g:186:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUseCaseDSL.g:187:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUseCaseDSL.g:187:4: (lv_name_1_0= RULE_ID )
            // InternalUseCaseDSL.g:188:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_8); 

            					newLeafNode(lv_name_1_0, grammarAccess.getUseCaseAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUseCaseRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,14,FOLLOW_9); 

            			newLeafNode(otherlv_2, grammarAccess.getUseCaseAccess().getLeftParenthesisKeyword_2());
            		
            // InternalUseCaseDSL.g:208:3: ( (lv_text_3_0= RULE_STRING ) )
            // InternalUseCaseDSL.g:209:4: (lv_text_3_0= RULE_STRING )
            {
            // InternalUseCaseDSL.g:209:4: (lv_text_3_0= RULE_STRING )
            // InternalUseCaseDSL.g:210:5: lv_text_3_0= RULE_STRING
            {
            lv_text_3_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_text_3_0, grammarAccess.getUseCaseAccess().getTextSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUseCaseRule());
            					}
            					addWithLastConsumed(
            						current,
            						"text",
            						lv_text_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getUseCaseAccess().getRightParenthesisKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUseCase"


    // $ANTLR start "entryRuleActors"
    // InternalUseCaseDSL.g:234:1: entryRuleActors returns [EObject current=null] : iv_ruleActors= ruleActors EOF ;
    public final EObject entryRuleActors() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleActors = null;


        try {
            // InternalUseCaseDSL.g:234:47: (iv_ruleActors= ruleActors EOF )
            // InternalUseCaseDSL.g:235:2: iv_ruleActors= ruleActors EOF
            {
             newCompositeNode(grammarAccess.getActorsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleActors=ruleActors();

            state._fsp--;

             current =iv_ruleActors; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleActors"


    // $ANTLR start "ruleActors"
    // InternalUseCaseDSL.g:241:1: ruleActors returns [EObject current=null] : (otherlv_0= 'actors:' ( (lv_actor_1_0= ruleActor ) )* ) ;
    public final EObject ruleActors() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_actor_1_0 = null;



        	enterRule();

        try {
            // InternalUseCaseDSL.g:247:2: ( (otherlv_0= 'actors:' ( (lv_actor_1_0= ruleActor ) )* ) )
            // InternalUseCaseDSL.g:248:2: (otherlv_0= 'actors:' ( (lv_actor_1_0= ruleActor ) )* )
            {
            // InternalUseCaseDSL.g:248:2: (otherlv_0= 'actors:' ( (lv_actor_1_0= ruleActor ) )* )
            // InternalUseCaseDSL.g:249:3: otherlv_0= 'actors:' ( (lv_actor_1_0= ruleActor ) )*
            {
            otherlv_0=(Token)match(input,16,FOLLOW_11); 

            			newLeafNode(otherlv_0, grammarAccess.getActorsAccess().getActorsKeyword_0());
            		
            // InternalUseCaseDSL.g:253:3: ( (lv_actor_1_0= ruleActor ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==17) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalUseCaseDSL.g:254:4: (lv_actor_1_0= ruleActor )
            	    {
            	    // InternalUseCaseDSL.g:254:4: (lv_actor_1_0= ruleActor )
            	    // InternalUseCaseDSL.g:255:5: lv_actor_1_0= ruleActor
            	    {

            	    					newCompositeNode(grammarAccess.getActorsAccess().getActorActorParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_11);
            	    lv_actor_1_0=ruleActor();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getActorsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"actor",
            	    						lv_actor_1_0,
            	    						"co7217.dsl.ucd.UseCaseDSL.Actor");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleActors"


    // $ANTLR start "entryRuleActor"
    // InternalUseCaseDSL.g:276:1: entryRuleActor returns [EObject current=null] : iv_ruleActor= ruleActor EOF ;
    public final EObject entryRuleActor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleActor = null;


        try {
            // InternalUseCaseDSL.g:276:46: (iv_ruleActor= ruleActor EOF )
            // InternalUseCaseDSL.g:277:2: iv_ruleActor= ruleActor EOF
            {
             newCompositeNode(grammarAccess.getActorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleActor=ruleActor();

            state._fsp--;

             current =iv_ruleActor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleActor"


    // $ANTLR start "ruleActor"
    // InternalUseCaseDSL.g:283:1: ruleActor returns [EObject current=null] : (otherlv_0= 'actor' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '=>' ( (otherlv_5= RULE_ID ) )* (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* ) ;
    public final EObject ruleActor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;


        	enterRule();

        try {
            // InternalUseCaseDSL.g:289:2: ( (otherlv_0= 'actor' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '=>' ( (otherlv_5= RULE_ID ) )* (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* ) )
            // InternalUseCaseDSL.g:290:2: (otherlv_0= 'actor' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '=>' ( (otherlv_5= RULE_ID ) )* (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* )
            {
            // InternalUseCaseDSL.g:290:2: (otherlv_0= 'actor' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '=>' ( (otherlv_5= RULE_ID ) )* (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* )
            // InternalUseCaseDSL.g:291:3: otherlv_0= 'actor' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= '=>' ( (otherlv_5= RULE_ID ) )* (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )*
            {
            otherlv_0=(Token)match(input,17,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getActorAccess().getActorKeyword_0());
            		
            // InternalUseCaseDSL.g:295:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUseCaseDSL.g:296:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUseCaseDSL.g:296:4: (lv_name_1_0= RULE_ID )
            // InternalUseCaseDSL.g:297:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_12); 

            					newLeafNode(lv_name_1_0, grammarAccess.getActorAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getActorRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalUseCaseDSL.g:313:3: (otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==18) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalUseCaseDSL.g:314:4: otherlv_2= 'extends' ( (otherlv_3= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,18,FOLLOW_7); 

                    				newLeafNode(otherlv_2, grammarAccess.getActorAccess().getExtendsKeyword_2_0());
                    			
                    // InternalUseCaseDSL.g:318:4: ( (otherlv_3= RULE_ID ) )
                    // InternalUseCaseDSL.g:319:5: (otherlv_3= RULE_ID )
                    {
                    // InternalUseCaseDSL.g:319:5: (otherlv_3= RULE_ID )
                    // InternalUseCaseDSL.g:320:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getActorRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_13); 

                    						newLeafNode(otherlv_3, grammarAccess.getActorAccess().getSuperTypeActorCrossReference_2_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_4=(Token)match(input,19,FOLLOW_14); 

            			newLeafNode(otherlv_4, grammarAccess.getActorAccess().getEqualsSignGreaterThanSignKeyword_3());
            		
            // InternalUseCaseDSL.g:336:3: ( (otherlv_5= RULE_ID ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==RULE_ID) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalUseCaseDSL.g:337:4: (otherlv_5= RULE_ID )
            	    {
            	    // InternalUseCaseDSL.g:337:4: (otherlv_5= RULE_ID )
            	    // InternalUseCaseDSL.g:338:5: otherlv_5= RULE_ID
            	    {

            	    					if (current==null) {
            	    						current = createModelElement(grammarAccess.getActorRule());
            	    					}
            	    				
            	    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_14); 

            	    					newLeafNode(otherlv_5, grammarAccess.getActorAccess().getUsecaseUseCaseCrossReference_4_0());
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            // InternalUseCaseDSL.g:349:3: (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==20) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalUseCaseDSL.g:350:4: otherlv_6= ',' ( (otherlv_7= RULE_ID ) )
            	    {
            	    otherlv_6=(Token)match(input,20,FOLLOW_7); 

            	    				newLeafNode(otherlv_6, grammarAccess.getActorAccess().getCommaKeyword_5_0());
            	    			
            	    // InternalUseCaseDSL.g:354:4: ( (otherlv_7= RULE_ID ) )
            	    // InternalUseCaseDSL.g:355:5: (otherlv_7= RULE_ID )
            	    {
            	    // InternalUseCaseDSL.g:355:5: (otherlv_7= RULE_ID )
            	    // InternalUseCaseDSL.g:356:6: otherlv_7= RULE_ID
            	    {

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getActorRule());
            	    						}
            	    					
            	    otherlv_7=(Token)match(input,RULE_ID,FOLLOW_15); 

            	    						newLeafNode(otherlv_7, grammarAccess.getActorAccess().getUsecaseUseCaseCrossReference_5_1_0());
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleActor"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000010802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000002002L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000100012L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000100002L});

}