package co7217.dsl.ucd.generator

/**
 * Serialization of entities using the DSL: used in slides
 */
import org.eclipse.emf.common.util.URI
import org.eclipse.emf.ecore.EObject
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.xtext.resource.XtextResourceSet

import com.google.inject.Injector

import co7217.dsl.ucd.UseCaseDSLStandaloneSetup
import co7217.dsl.ucd.useCaseDSL.Actor
import co7217.dsl.ucd.useCaseDSL.Actors
import co7217.dsl.ucd.useCaseDSL.UseCase
import co7217.dsl.ucd.useCaseDSL.UsecaseEMFModel
import co7217.dsl.ucd.useCaseDSL.Usecases
import submission_helper.SubmissionHelper

class submission_solution {

	def static void main(String[] args) {
		def path = 'src/main/resources/example1.ucd'
		//def path = 'src/main/resources/example2.ucd'

		SubmissionHelper.check_solution('sas92', 'week_19', solution);
	}

	def static solution = { path ->
		String text = ''

		// do this only once per application
		Injector injector = new UseCaseDSLStandaloneSetup().createInjectorAndDoEMFRegistration();

		// obtain a resourceset from the injector
		XtextResourceSet resourceSet = injector.getInstance(XtextResourceSet.class);

		// load a resource by URI, in this case from the file system
		Resource resource = resourceSet.getResource(URI.createFileURI(path), true);

		UsecaseEMFModel model = resource.getContents().get(0)

		text += traverse(model)
		text

	}

	def static String traverse(List<EObject> list) {
		String text = ''
		for (obj in list) {
			text += traverse(obj)
		}
		text
	}

	def static String traverse(EObject object) {
		String text = ''

		switch(object) {
			case UsecaseEMFModel :
				text += "@startuml"
				text += "\n"
				text += traverse(object.usecases)
				text += traverse(object.actor)
				text += "@enduml"
				break

			case Usecases :
				text += generate(object)
				break

			case UseCase :
				text += generate(object)
				break

			case Actors :
				text += generate(object)
				break

			case Actor :
				text += generate(object)
				break
		}

		text
	}

	def static generate(EObject object) {
		String text = ''
		switch(object) {

			case Usecases :
			text += traverse(object.useCase)
			break
			
			case UseCase :
			text += """(${object.name})"""
			text += '\n'
			break
			
			case Actors :
				text += traverse(object.actor)
			break

			case Actor:
				text += """:${object.name}:"""
				if(object.superType != null) {
					
					text += """ -up-|>${object.superType.name}"""
				}
				text +='\n'
				text += object.usecase.collect{"""${object.name} --> ${it.name}\n"""
				}.join("")
			break

		}
		text
	}
}